# TrustUsBank — multi-cluster bundle (raw manifests, by cluster)

This bundle contains **every Kubernetes manifest** the multi-cluster demo
applies, organised by which cluster receives it. **No install scripts** —
just the YAML.

## Layout

```
shared/                # Applied to ALL three clusters (cacerts, license,
                       # ServiceMeshController, namespaces with the
                       # topology.istio.io/network label)
trustusbank-edge/      # Presentation tier — chatbot only
trustusbank-bank/      # Bank tier — agents, MCPs, agentgateway,
                       # observability, Solo Mesh mgmt-server
trustusbank-vendor/    # Vendor tier — currency-converter rug-pull target
                       # + mock-attacker C2 sink
```

## Cross-cluster federation primitives

Solo Istio Ambient peering owns federation (NOT Solo Mesh's
`VirtualDestination` translator — that fights with peering in this
version and produces ServiceEntries with zero endpoints).

The control plane and data plane both need wiring:

| Layer | Resource | Where |
|---|---|---|
| Data plane: HBONE termination | `gatewayClassName: istio-eastwest` Gateway | each cluster's `01-peering/eastwest-gateway.yaml` |
| Data plane: remote endpoint refs | `gatewayClassName: istio-remote` Gateways | each cluster's `01-peering/peer-<other>.yaml` |
| Control plane: remote k8s API access | `istio-remote-secret-<peer>` Secrets | each cluster's `02-remote-secrets/` |
| istiod license unlock | `SOLO_LICENSE_KEY` env on `istiod-gloo` | each cluster's `00-istiod-license-env-patch.yaml` |
| ztunnel multi-cluster | `L7_ENABLED=true` env on `ztunnel` | each cluster's `00-ztunnel-l7-env-patch.yaml` |
| Network classification | `topology.istio.io/network=<cluster>` label on every workload namespace | `shared/00-namespaces-and-labels.yaml` |
| Intermediate cert SAN | All intermediates signed with `spiffe://cluster.local/...` | `shared/01-cacerts-secret.example.yaml` |

Once all the above is in place, every Service in a peered cluster is
reachable from the others as:

- `<svc>.<ns>.mesh.internal` — **global** (when the Service has
  `istio.io/global=true`)
- `<svc>.<ns>.svc.cluster.local` — cluster-local, no cross-cluster

## Apply order

```
# On every cluster:
kubectl apply -f shared/

# Then on each cluster (use the right --context):
kubectl --context=kind-trustusbank-edge   apply -R -f trustusbank-edge/
kubectl --context=kind-trustusbank-bank   apply -R -f trustusbank-bank/
kubectl --context=kind-trustusbank-vendor apply -R -f trustusbank-vendor/
```

## Three rug-pull defence layers

All three are intact in this bundle:

1. **cosign signature verification** at admission (image-layer defence) —
   `trustusbank-bank/10-platform/agentregistry/` shows the publisher path.
2. **agentgateway policy** at the gateway — `trustusbank-bank/12-agentgateway/`
   contains `AgentgatewayPolicy` CRs that filter MCP tool calls.
3. **kagent AccessPolicy** at the per-agent waypoint — `trustusbank-bank/15-accesspolicies/`
   denies disallowed callers. SPIFFE is preserved end-to-end through the
   east-west GW so cross-cluster `ServiceAccount` subjects (e.g. the chatbot
   on edge calling support-bot on bank) are enforced.

## CRD reference (every kind in this bundle)

| Kind | API group | Role |
|---|---|---|
| `ServiceMeshController` | operator.gloo.solo.io | Declarative Solo Istio install (one per cluster). |
| `Gateway` (`istio-eastwest` / `istio-remote`) | gateway.networking.k8s.io | East-west GW + per-remote peer references. Solo Istio peering primitives. |
| `Gateway` (`istio-waypoint` / `agentgateway-waypoint`) | gateway.networking.k8s.io | Per-agent waypoints that enforce AccessPolicy. |
| `HTTPRoute` | gateway.networking.k8s.io | Wires agentgateway HTTP routes. |
| `Workspace` / `WorkspaceSettings` | admin.gloo.solo.io | Solo Mesh governance scope (not federation — that's Solo Istio's job now). |
| `KubernetesCluster` | admin.gloo.solo.io | Solo Mesh's per-cluster registration. |
| `Agent` / `ModelConfig` / `RemoteMCPServer` | kagent.dev/v1alpha2 | Agent + model + MCP server declarations. |
| `AccessPolicy` | policy.kagent-enterprise.solo.io | **Defence layer 3** — per-agent invocation allowlist. SPIFFE-aware. |
| `AgentgatewayPolicy` / `AgentgatewayBackend` | agentgateway.dev | **Defence layer 2** — MCP tool / method filtering. |
| `AuthorizationPolicy` | security.istio.io | Mesh-level L4 ALLOW/DENY by SPIFFE identity. |
| `Telemetry` | telemetry.istio.io | Routes mesh telemetry to OTel collector. |
| `PodMonitor` / `PrometheusRule` / `AlertmanagerConfig` | monitoring.coreos.com | Observability stack — fires `KagentAccessPolicyDeny` on waypoint 403s. |
| `Secret` (`cacerts`, `solo-istio-license`, `istio-remote-secret-*`) | core | Critical multi-cluster glue. See file comments for what each must contain. |
