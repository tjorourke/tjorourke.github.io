# `trustusbank-bank/` — Bank tier — agents, MCPs, agentgateway, observability, Solo Mesh mgmt-server

Manifests in this folder are applied to **the `trustusbank-bank` cluster only**.

Apply order (numeric prefix matches `shared/` ordering — `shared/`
applies first):

## `01-peering/`

- `eastwest-gateway.yaml`
- `peer-trustusbank-edge.yaml`
- `peer-trustusbank-vendor.yaml`

## `02-remote-secrets/`

- `istio-remote-secret-trustusbank-edge.example.yaml`
- `istio-remote-secret-trustusbank-vendor.example.yaml`

## `10-platform/`

- `values-slim.yaml`
- `values.template.yaml`
- `values.yaml`

## `11-observability/`

- `agentgateway-podmonitor.yaml`
- `alertmanager-email.yaml`
- `authz-deny-alert.yaml`
- `istio-telemetry.yaml`
- `kagent-accesspolicy-deny-alert.yaml`
- `mailhog.yaml`

## `12-agentgateway/`

- `backends.yaml`
- `gateway.yaml`
- `httproutes.yaml`
- `prompt-guard.yaml`
- `rate-limit.yaml`
- `tool-allowlist.yaml`
- `tracing.yaml`

## `13-mcp-servers/`

- `account-mcp.yaml`
- `ticket-mcp.yaml`
- `transaction-mcp.yaml`

## `14-agents/`

- `agent-fraud-bot.yaml`
- `agent-support-bot.yaml`
- `agent-triage-bot.yaml`
- `modelconfig.yaml`
- `remote-mcp-servers.yaml`
- `telemetry.yaml`

## `15-accesspolicies/`

- `accesspolicy-support-bot-currency.yaml`

## `16-ambient-policies/`

- `allow-agents-to-mcp.yaml`
- `deny-all-cross-ns.yaml`
- `ztunnel-log-level.yaml`

## `17-a2a/`

- `tenant-isolation.yaml`

## `20-gloo-mesh/`

- `workspace.yaml`
- `workspacesettings.yaml`

