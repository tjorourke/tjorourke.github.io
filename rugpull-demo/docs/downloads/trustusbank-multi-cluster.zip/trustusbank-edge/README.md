# `trustusbank-edge/` — Presentation tier — chatbot frontend only

Manifests in this folder are applied to **the `trustusbank-edge` cluster only**.

Apply order (numeric prefix matches `shared/` ordering — `shared/`
applies first):

## `01-peering/`

- `eastwest-gateway.yaml`
- `peer-trustusbank-bank.yaml`
- `peer-trustusbank-vendor.yaml`

## `02-remote-secrets/`

- `istio-remote-secret-trustusbank-bank.example.yaml`
- `istio-remote-secret-trustusbank-vendor.example.yaml`

## `10-chatbot/`

- `chatbot.yaml`

